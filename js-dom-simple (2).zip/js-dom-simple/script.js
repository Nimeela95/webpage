
function changeText() {
    document.getElementById("mainHeading").innerText = "You clicked the button!";
}
